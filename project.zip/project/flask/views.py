from flask import Flask, render_template, request, redirect, url_for, flash, session
from dbhandler import Mysqlhandler

app = Flask(__name__)
app.secret_key = b'_5#y2L"F4Q8z\n\xec]'

PHONE = 0

@app.route('/')                                     #for redirecting to the main page
def index():
    return redirect(url_for('create_user'))

@app.route('/user_or_not', methods=['POST', 'GET'])                          #redirects to signup/login based on what is chosen
def create_user() -> 'html':
    return render_template('entry.html',
    the_title='Are you a user already?')


@app.route('/user/buy_or_sell', methods=['POST'])   #redirects to login or signup 
def buy_or_sell() -> 'html':

    if request.method == 'POST':
        if request.form['submit_button'] == 'Signup':
            return render_template('welcomeS.html', the_title='Signup as:')
        elif request.form['submit_button'] == 'Login':
            return render_template('welcomeL.html', the_title='Login as:')


@app.route('/user/signup', methods=['POST'])        #redirects to customer/vendor signup page
def c_or_v() -> 'html':

    if request.method == 'POST':
        if request.form['submit_button'] == 'Customer':
            return render_template('csign.html',)
        elif request.form['submit_button'] == 'Vendor':
            return render_template('vsign.html',)


@app.route('/user/signc', methods=['POST', 'GET'])    #for redirecting customer signup
def signc():
    
    msg = ''

    if request.method == 'POST' and 'uname' in request.form and 'pwd' in request.form and 'pwd_repeat' in request.form :

        uname = request.form['uname']
        pwd = request.form['pwd']
        pwd_repeat = request.form['pwd_repeat']
        str3 = 'Passwords don\'t match'

        if pwd != pwd_repeat :
            msg = str3
            return render_template('csign.html', msg=msg
            )
        
        handleMe = Mysqlhandler()
        r = Mysqlhandler.signup(handleMe, uname, pwd, 1)
        str1 = "Signed up and auto-Logged in as:" + uname
        str2 = "ERROR: USERNAME TAKEN"

        if(r != None):

            if(r==3):
                return render_template('csign.html', msg = str2
            )

            session['loggedin'] = True
            session['uname'] = r[0]
            return render_template('results.html',
            the_username=uname, string=str1, uname=session['uname']
            )
        else :
            msg = str2
            return render_template('csign.html', msg=msg
            )
    return render_template('csign.html')

    

@app.route('/user/signv', methods=['POST', 'GET'])    #for redirecting vendor signup
def signv():
    msg = ''

    if request.method == 'POST' and 'uname' in request.form and 'pwd' in request.form and 'pwd_repeat' in request.form :

        uname = request.form['uname']
        pwd = request.form['pwd']
        pwd_repeat = request.form['pwd_repeat']
        str3 = 'Passwords don\'t match'

        if pwd != pwd_repeat :
            msg = str3
            return render_template('vsign.html', msg=msg
            )
        
        handleMe = Mysqlhandler()
        r = Mysqlhandler.signup(handleMe, uname, pwd, 2)
        str1 = "Signed up and auto-Logged in as:" + uname
        str2 = "ERROR: USERNAME TAKEN"

        if(r != None):

            session['loggedin'] = True
            session['uname'] = r[0]
            return render_template('results2.html',
            the_username=uname, string=str1, uname=session['uname']
            )
        else :
            msg = str2
            return render_template('vsign.html', msg=msg
            )
    else:
        msg = 'Enter the details'
    
    return render_template('vsign.html', msg=msg)




@app.route('/user/update', methods=['POST'])        #
def update_user() -> 'html':
    return render_template('update.html',
    the_title='Enter the updated details!')


@app.route('/user/login', methods=['POST'])         #redirects to customer/vendor login page
def v_l() -> 'html':

    if request.method == 'POST':
        if request.form['submit_button'] == 'Customer':
            return render_template('clogin.html')
        elif request.form['submit_button'] == 'Vendor':
            return render_template('vlogin.html')

            

@app.route('/user/loginc', methods=['POST', 'GET'])    #for redirecting customer login
def loginc():
    return render_template('clogin.html')

@app.route('/user/loginv', methods=['POST', 'GET'])    #for redirecting vendor login
def loginv():
    return render_template('vlogin.html')



@app.route('/user/delete', methods=['POST'])        #
def delete_user() -> 'html':

    return render_template('delete.html',
    )

@app.route('/user/done', methods=['POST'])          #
def done() -> 'html':
    phno = request.form['phno']

    return render_template('done.html',
    )

@app.route('/user/sign_form', methods=['POST'])     # for buyer -> customer signup
def sign_form() -> 'html':

    msg = ''

    if request.method == 'POST' and 'uname' in request.form and 'pwd' in request.form and 'pwd_repeat' in request.form :

        uname = request.form['uname']
        pwd = request.form['pwd']
        pwd_repeat = request.form['pwd_repeat']
        str3 = 'Passwords don\'t match'

        if pwd != pwd_repeat and pwd != None and pwd_repeat != None:
            msg = str3
            return render_template('csign.html', msg=msg
            )
        
        handleMe = Mysqlhandler()
        r = Mysqlhandler.signup(handleMe, uname, pwd, 2)
        str1 = "Signed up and auto-Logged in as:" + uname
        str2 = "ERROR: USERNAME TAKEN"

        if(r != None):
            
            session['loggedin'] = True
            session['uname'] = r[0]
            return render_template('results.html',
            the_username=uname, string=str1, uname=session['uname']
            )

        else :
            msg = str2
            return render_template('csign.html', msg=msg
            )
    return render_template('csign.html')

@app.route('/user/sign_form2', methods=['POST'])    #for vendor signup
def sign_form2() -> 'html':

        
    msg = ''

    if request.method == 'POST' and 'uname' in request.form and 'pwd' in request.form and 'pwd_repeat' in request.form :

        uname = request.form['uname']
        pwd = request.form['pwd']
        pwd_repeat = request.form['pwd_repeat']
        str3 = 'Passwords don\'t match'

        if pwd != pwd_repeat :
            msg = str3
            return render_template('vsign.html', msg=msg
            )
        
        handleMe = Mysqlhandler()
        r = Mysqlhandler.signup(handleMe, uname, pwd, 2)
        str1 = "Signed up and auto-Logged in as:" + uname
        str2 = "ERROR: USERNAME TAKEN"

        if(r != None):

            if(r==3):
                return render_template('vsign.html', msg = str2
            )

            session['loggedin'] = True
            session['uname'] = r[0]
            return render_template('results2.html',
            the_username=uname, string=str1, uname=session['uname']
            )
        else :
            msg = str2
            return render_template('vsign.html', msg=msg
            )
    return render_template('vsign.html')
    

@app.route('/user/login_form', methods=['POST'])    #for buyer->customer login
def login_form() -> 'html':

    msg = ''

    if request.method == 'POST' and 'uname' in request.form and 'pwd' in request.form:
        uname = request.form['uname']
        pwd = request.form['pwd']

        handleMe2 = Mysqlhandler()
        r = Mysqlhandler.login(handleMe2, uname, pwd, 1)
        str1 = "You are logged in as " + uname
        str2 = "Invalid credentials/User doesn't exist"

        if(r != None and r!=0):

            # handleMe3 = Mysqlhandler()
            # account = []
            # account = Mysqlhandler.log(handleMe3, uname, pwd, 1)
            session['loggedin'] = True
            session['uname'] = r[0]

            return render_template('results.html', uname=session['uname'])

            
        else :
            
            msg = str2
            return render_template('clogin.html', msg=msg)
            
    else:
        msg = 'Enter the details'
    
    return render_template('clogin.html', msg=msg)

@app.route('/user/login_form2', methods=['POST'])   #for vendor login
def login_form2() -> 'html':

    msg = ''

    if request.method == 'POST' and 'uname' in request.form and 'pwd' in request.form:

        uname = request.form['uname']
        pwd = request.form['pwd']

        handleMe2 = Mysqlhandler()
        r = Mysqlhandler.login(handleMe2, uname, pwd, 2)
        str1 = "You are logged in as " + uname
        str2 = "Invalid credentials/User doesn't exist"

        if(r != None and r!=0):
            
            session['loggedin'] = True
            session['uname'] = r[0]

            return render_template('results2.html', uname=session['uname'])
            
        else :
            msg = str2
            return render_template('vlogin.html', msg=msg)
            # return render_template('results2.html',
            # the_username=uname, string=str2
            # )
    else:
        msg = 'Enter the details'
    
    return render_template('clogin.html', msg=msg)

@app.route('/user/make', methods=['POST', 'GET'])   #for vendor login
def make() -> 'html':

    msg = ''

    return render_template('items.html')

@app.route('/user/add_item', methods=['POST', 'GET'])   #for vendor login
def add_item() -> 'html':

    msg = ''
    item_name = request.form['item_name']
    # vendor_id = request.form['vendorID']
    uname = request.form['unm']

    handleMe = Mysqlhandler()
    id = Mysqlhandler.get_id2(handleMe, uname)

    req_id = id[0]

    handleMe2 = Mysqlhandler()
    r = Mysqlhandler.item_creation(handleMe2, item_name, req_id)

    handleMe3 = Mysqlhandler()
    req_id2 = str(req_id)
    rows = Mysqlhandler.item_listing(handleMe3, req_id2)
    print("GGGGGGGGGGGGGGGGGGGGGGGG")
    print(rows)

    return render_template('update_item.html', products=rows)


@app.route('/user/prod', methods=['POST', 'GET'])   #for products
def prod() -> 'html':

    msg = ''
    var1 = []

    handleMe2 = Mysqlhandler()
    var1 = Mysqlhandler.product(handleMe2)                  #all products are stored in list

    return render_template('prod2.html', products=var1)


@app.route('/user/search', methods=['POST', 'GET'])   #for products
def search():
    search_req = request.form['search_in']
    print(">>>>>>>>>>>>>>>>>>>>>>>>>>>")
    print(search_req)

    handleMe2 = Mysqlhandler()
    records = Mysqlhandler.search(handleMe2, search_req)  
    print("tftftftftftftftftfftttft")
    print(records)
    return render_template('prod2.html', products=records)



@app.route('/user/buy', methods=['POST', 'GET'])   #buy now
def buy():
    name = request.form['b_n'] #name of the user
    prod_name = request.form['prod_name']
    
    print("---------------------------------")
    print(prod_name)
    print("---------------------------------")
    handleme = Mysqlhandler()
    prod_id = Mysqlhandler.get_id(handleme, prod_name)
    print("++++++++++++++++++++++++++++++++++++")
    print(prod_id[0])
    print("++++++++++++++++++++++++++++++++++++")

    handleMe2 = Mysqlhandler()
    id = Mysqlhandler.buy(handleMe2, prod_id[0], name)  

    handleMe3 = Mysqlhandler()
    var2 = Mysqlhandler.orders(handleMe3, id)  

    return render_template('orders.html', products=var2)

@app.route('/user/add', methods=['POST', 'GET'])   #for products
def add() -> 'html':

    var1 = []

    handleMe2 = Mysqlhandler()
    # var1 = Mysqlhandler.add(handleMe2)                  #all products are stored in list

    try:
		
        quantity = int(request.form['quantity'])
        code = request.form['code']
        name = request.form['name']
        print("***************************************")
        
        print(quantity)
        row = Mysqlhandler.add(handleMe2, code)     

		# validate the received values
		
        if quantity and request.method == 'POST':
			
            itemArray = { row[3] : {'name' : row[0],'code' : row[3], 'quantity' : quantity }   }
			
			
            all_total_price = 0
			
            all_totalquantity = 0
			
			
            session.modified = True
			
            if 'cart_item' in session:
				
                if row[3] in session['cart_item']:
					
                    for key, value in session['cart_item'].items():
						
                        if row[name] == key:
							
                            oldquantity = session['cart_item'][key]['quantity']
                            totalquantity = oldquantity + quantity
                            session['cart_item'][key]['quantity'] = totalquantity
							# session['cart_item'][key]['total_price'] = totalquantity * row['price']
				
                else:
                    session['cart_item'] = array_merge(session['cart_item'], itemArray)

                for key, value in session['cart_item'].items():

                    individualquantity = int(session['cart_item'][key]['quantity'])
					# individual_price = float(session['cart_item'][key]['total_price'])
                    all_totalquantity = all_totalquantity + individualquantity
					# all_total_price = all_total_price + individual_price
			
            else:
				
                session['cart_item'] = itemArray
                all_totalquantity = all_totalquantity + quantity
				# all_total_price = all_total_price + quantity * row['price']
			
            session['all_totalquantity'] = all_totalquantity
            session['all_total_price'] = all_total_price
			
            return redirect(url_for('prod'))

        else:
            return 'Error while adding item to cart'

    except Exception as e:
        print(e)

    handleMe2 = Mysqlhandler()
    var1 = Mysqlhandler.product(handleMe2)                  #all products are stored in list

    return render_template('prod2.html', products=var1)

	

def array_merge( first_array , second_array ):
	if isinstance( first_array , list ) and isinstance( second_array , list ):
		return first_array + second_array
	elif isinstance( first_array , dict ) and isinstance( second_array , dict ):
		return dict( list( first_array.items() ) + list( second_array.items() ) )
	elif isinstance( first_array , set ) and isinstance( second_array , set ):
		return first_array.union( second_array )
	return False	

app.run(host = "127.0.0.1", port = 5050, debug = True)
