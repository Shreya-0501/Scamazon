# Scamazon

- Native app/ mobile app (front end -> kivy/react)
  - Customer:
    - Just display of orders

  - Vendor:
    - Your Items:
      - Icons for delete on each prod
      - Edit prod info on each prod
