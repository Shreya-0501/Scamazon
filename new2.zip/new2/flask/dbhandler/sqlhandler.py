from flask import Flask, render_template, request
from getpass import getpass
import mysql.connector
from mysql.connector import connect, Error
from datetime import datetime

class Mysqlhandler:

    def login(self, uname, pwd, num):
       
        ######################################################

        mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            # password=getpass("Enter password: "),
            password = 'Sreekar8697*',
            database = "challa2"
        )

        enteredname = uname
        enteredpass = pwd

        if num == 1:
            usertype = "buyer"         #either_buyer_or_vender

        elif num == 2:
            usertype = "vendor"

        userid = -1
        userexists = 0
        passmatch = 0
        rowadd = -1

        mycursor = mydb.cursor(buffered=True)
        mycursor.execute("SELECT * FROM " + usertype + "")
        # mydb.commit()
        records = mycursor.fetchall()

        for i in range(0, mycursor.rowcount):
            if(enteredname == records[i][0]):
                userexists = 1
                rowadd = i
                break

        if(userexists):
            if(enteredpass == records[rowadd][1]):
                passmatch = 1
                userid = records[i][2]

        if(userexists == 1 and passmatch == 1):
            ok = str(userid)
            q = "select * from " + usertype + " where " + usertype+"id" + "=" + ok
            mycursor.execute(q)
            r = mycursor.fetchone()
            print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
            print(r)
            return r

        elif(userexists == 0 or passmatch == 0):
            return 0

    
    
    def signup(self, uname, pwd, num):
        
        ################################################

        mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            password = 'Sreekar8697*',
            database = "challa2"
        )

        enteredname = uname
        enteredpass = pwd

        if num == 1:
            usertype = "buyer"         #either_buyer_or_vender

        elif num == 2:
            usertype = "vendor"

        userid = -1
        userexists = 0
        passmatch = 0
        signupstat = 0

        mycursor = mydb.cursor(buffered=True)
        mycursor.execute("SELECT * FROM " + usertype + "")
        # mydb.commit()
        records = mycursor.fetchall()
        print("*****************************")
        print(records)

        for i in range(0, mycursor.rowcount): #checks_if_username_is_taken
            if(enteredname == records[i][0]):
                userexists = 1
                break
                # return 3
                

        if(userexists != 1): #if_username_is_not_used
            
            sql_signup_statement = "INSERT INTO " + usertype + " (username, pass) VALUES (%s, %s)"
            sql_value = (enteredname, enteredpass)

            mycursor = mydb.cursor()
            mycursor.execute(sql_signup_statement, sql_value)
            records = mycursor.fetchall()
            mydb.commit()

            # mycursor = mydb.cursor(buffered=True)
            # query = "INSERT INTO "+ usertype + "(username, pass)"
            # mycursor.execute(query + "VALUES (%s, %s)", (enteredname, enteredpass))
            # mydb.commit()
            # # print()
            signupstat = 1

            rowadd = -1

        #logging_in_after_signing_up

            mycursor.execute("SELECT * FROM " + usertype + "")
            # mydb.commit()
            records = mycursor.fetchall()

            for i in range(0, mycursor.rowcount):
                if(enteredname == records[i][0]):
                    userexists = 1
                    rowadd = i
                    break

            if(userexists):
                if(enteredpass == records[rowadd][1]):
                    passmatch = 1
                    userid = records[i][2]

            if(userexists == 1 and passmatch == 1):
                ok = str(userid)
                q = "select * from " + usertype + " where " + usertype+"id" + "=" + ok
                mycursor.execute(q)
                r = mycursor.fetchone()
                print("********************")
                print(r)
                print(r[0])
                return r
                

        else:
            return 3

    def item_creation(self, item_name, vendorid):

        ################################################

        mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            password = 'Sreekar8697*',
            database = "challa2"
        )

        # item_name = input("enter item name: ")
        # vendorid = input("enter vendor id: ")

        usertype = "vendor"
        now = datetime.now()

        sql_item_listing_statement = "INSERT INTO items (i_name, listedon, listedby)VALUE (%s, %s, %s)"
        sql_item_value = (item_name, now, vendorid)


        mycursor = mydb.cursor(buffered=True)
        mycursor.execute(sql_item_listing_statement, sql_item_value)
        mydb.commit()

        # print("item ", item_name, "added by ", vendorid)
        return 1

    def item_listing(self, vendorid):
        
        ################################################

        mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            password = 'Sreekar8697*',
            database = "challa2"
        )
        usertype = "vendor"
        # vendorid = input("enter vendor id: ")

        now = datetime.now()

        # sql_item_listing_statement = "SELECT * FROM items WHERE listedby = %s ORDER BY listedon;"
        sql_item_listing_statement = "select * from items where listedby ="+vendorid+""
        sql_item_value = int(vendorid)

        mycursor = mydb.cursor(buffered=True)
        mycursor.execute(sql_item_listing_statement)
        records = mycursor.fetchall()

        # for row in records:
        #     print(row[0], row[1])
        
        return records
        

        # print("items by ", vendorid, "\n")

    def product(self):

        mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            password = 'Sreekar8697*',
            database = "challa2"
        )
        mycursor = mydb.cursor(buffered=True)

        mycursor.execute("SELECT * FROM items")
        records = mycursor.fetchall()

        for row in records:
            print(row[0], row[1])

		
        return records

    def add(self, code):
        mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            password = 'Sreekar8697*',
            database = "challa2"
        )
        mycursor = mydb.cursor(buffered=True)

        mycursor.execute("SELECT * FROM product WHERE i_id=%s", code)
        row = mycursor.fetchone()

        return row

    def buy(self, prod_id, name):              
        mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            password = 'Sreekar8697*',
            database = "challa2"
        )
        print("&&&&&&&&&&&&&&&&&&&&&&")
        print(prod_id)
        print(name)
        print("&&&&&&&&&&&&&&&&&&&&&&")
        mycursor = mydb.cursor(buffered=True)
        now = datetime.now()

        q = "select * from buyer where username='" + name+ "'"

        mycursor.execute(q)
        res =  mycursor.fetchone()

        print(res)

        id = res[2]
        prod_id2 = str(prod_id)

        q = "INSERT INTO orders (ordered_id, o_date, ordered_by )VALUE (%s, %s, %s)"
        sql_item_value = (prod_id2, now, id)

        mycursor.execute(q,sql_item_value)
        mydb.commit()

        print("Executed dw")
        return id


    def orders(self, id):
        mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            password = 'Sreekar8697*',
            database = "challa2"
        )
        mycursor = mydb.cursor(buffered=True)
        
        strid = str(id)
        q = "select ordered_id from orders where ordered_by=" + strid

        mycursor.execute(q)
        res =  mycursor.fetchall()
        new = []

        for i in range(len(res)):
            for j in range(len(res[i]) ):
                if j == 0:
                    new.append(res[i][j])
        
        print(new)

        n = []

        for r in new:
            p= "select i_name from items where i_id = " + str(r)
            mycursor.execute(p)
            ans = mycursor.fetchone()
            n.append(ans)
            
        print(n)


        print("Executed dw2")
        # print(res)
        return n


    def log(self, uname, pwd, num):

        mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            password = 'Sreekar8697*',
            database = "challa2"
        )
        mycursor = mydb.cursor(buffered=True)

        if num == 1:
            usertype = "buyer"         #either_buyer_or_vender

        elif num == 2:
            usertype = "vendor"

        
        mycursor.execute('SELECT * FROM %s WHERE username = \'%s\' AND pass = \'%s\' ', usertype, (uname, pwd))
        account = mycursor.fetchone()

        
        print(account)
        return account

    def get_id(self, prod_name):
        mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            password = 'Sreekar8697*',
            database = "challa2"
        )
        mycursor = mydb.cursor(buffered=True)

        q="select i_id from items where i_name = '"+prod_name+"'"
        mycursor.execute(q)

        prod_id = mycursor.fetchone()

        print(prod_id)

        return prod_id

    def get_id2(self, u_name):
        mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            password = 'Sreekar8697*',
            database = "challa2"
        )
        mycursor = mydb.cursor(buffered=True)

        q="select vendorid from vendor where username = '"+u_name+"'"
        mycursor.execute(q)

        id = mycursor.fetchone()
        print("#########################")
        print(id)

        return id


######################################################



    # usertype = "buyer"
    # search_query = input("enter search query: ")

############################


    def convert(lst):
        return (lst[0].split())


    def search(self, search_query):

        mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            password="mysqlpassword",
            database="challa"
        )

        mycursor = mydb.cursor()

        split = self.convert(search_query)
        sql_search = "SELECT*FROM items WHERE"

        for x in range(len(split)):
            if(x == 0):
                sql_search = sql_search + " i_name LIKE %" + split[x] + "%"
            else:
                sql_search = sql_search + " OR i_name LIKE %" + split[x] + "%"

        sql_search = sql_search + ";"


        mycursor.execute(sql_search)
        records = mycursor.fetchall()

        # print(records)
        print("????????????????????????")
        print(search_query)

        return records




            



    




        